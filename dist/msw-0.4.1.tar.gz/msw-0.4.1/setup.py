from setuptools import setup

setup(
    name="msw",
    author="Jim Thompson",
    author_email="jimthompson5802@aol.com",
    packages=['msw'],
    version='0.4.1',
    install_requires=['scikit-learn']
)
